#include<iostream>

int main() {
	std::cout << std::endl;
	std::cout << "        ��((((((((((((          " << std::endl;
	std::cout << "        oooooooooooooooo        " << std::endl;
	std::cout << "       o                o       " << std::endl;
	std::cout << "      o     \"\"    \"\"     o      " << std::endl;
	std::cout << "   oooo     ��    ��     oooo   " << std::endl;
	std::cout << "   O  o                  o  O   " << std::endl;
	std::cout << "   O  o        <         o  O   " << std::endl;
	std::cout << "   oooo                  oooo   " << std::endl;
	std::cout << "      o    ````   ```    o      " << std::endl;
	std::cout << "      o       \'\'\'\'       o      " << std::endl;
	std::cout << "       o                o       " << std::endl;
	std::cout << "        oooooooooooooooo        " << std::endl;
	std::cout << std::endl;
}
